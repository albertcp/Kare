package net.nedteam.nedid;

import android.support.v4.content.FileProvider;

public class GenericFileProvider extends FileProvider {

}